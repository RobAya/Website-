<?php 
session_start();
include("config.php");

?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/Register</title>
<style>
.error{color: #FF0000;}
</style>
</head>
<body background="pic.jpg">

<?php

$NameEr=$LnameEr=$EmailEr=$PasswordEr="";

$Name=$LName=$Email=$password="";


if($_SERVER["REQUEST_METHOD"]=="POST"){
   if(empty($_POST["name"])){
	 $NameEr="Name is required!";  
     }else{
	   $Name=Check($_POST["name"]);
	   if(!preg_match("/^[a-zA-z ]*$/",$Name)){
		   $NameEr= "Only Letters!";
		   }
	   }
	if(empty($_POST["Lname"])){
	   $LnameEr="Last name required!";
     }else{
		$LName=Check($_POST["Lname"]);
		if(!preg_match("/^[a-zA-z ]*$/",$LName)){
		$LnameEr="Only Letters!";
		}
		}
   if(empty($_POST["email"])){
	  $EmailEr="Email is required!";
	 }else{
		$Email= Check($_POST["email"]);
			if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
			$EmailEr="invalid Email!";
			}
				$query= "SELECT * from userinfo WHERE Email='$Email'";
				$result= mysqli_query($connection, $query);
				while($row = mysqli_fetch_row($result)){
					//var_dump($row);
					if($row[3]==$Email){
						$EmailEr="Email already registered!";
					}
				}
		}
	if(empty($_POST['pwd'])){
	   $PasswordEr="Password is required!";
   }else{
	$password=Check($_POST['pwd']);
		if(strlen($password)<5){
		$PasswordEr="Password is too short!";
		}if(strlen($password)>9){
		$PasswordEr="Password is too long!";	
		}
	}
$MotherOfAllErr=trim($EmailEr.$PasswordEr.$LnameEr.$NameEr);

if(empty($MotherOfAllErr)){
if(!$connection){
	die("Connection failed: ".$connection->connect_Err);	
	}
$password=md5($password);
$query="INSERT INTO userinfo (ID,First_Name,Last_Name,Email,Password)
VALUES (NULL,'$Name','$LName','$Email','$password')";	

if(mysqli_query($connection, $query)){
	echo "Accounting Successfully MADE!".'<br />'."Please Log in!";
}
else{
	echo "Mistakes were made =/";
}
	

}	
}

function Check($data){
	$data= trim($data);
	$data= stripslashes($data);
	$data= htmlspecialchars($data);
	$data= strip_tags($data);
	return $data;
}
?>
<font color="white">
<h1><u> Register</u></h1>
<p><span class="error">*required field!</span></p>

<form method="post" action ="<?php echo
htmlspecialchars($_SERVER["PHP_SELF"]);?>">

<fieldset>
First Name:<br> 
<input type ='text' name='name' value="<?php echo $Name;?>"/>
<span class="error">*<?php echo $NameEr;?></span> 
<br><br>
Last Name:<br>
<input type ='text' name ='Lname' value="<?php echo $LName;?>"/>
<span class="error">*<?php echo $LnameEr;?></span>
<br><br>
E-mail:<br>
<input type ='text' name='email' value="<?php echo $Email;?>"/>
<span class="error">*<?php echo $EmailEr;?></span>
<br><br>
Password:<br> 
<input type ='password' name ='pwd'/>
<span class="error">*<?php echo $PasswordEr;?></span>
<br><br>
<input type="submit" name="submit" value="Submit"/>
</fieldset>
</form>
</font>

<h3><a href ="Home.php">Return to Home page</a></h3>

</body>
</html>
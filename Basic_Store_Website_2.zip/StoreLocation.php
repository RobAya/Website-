<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/storelocation</title>
<script src="http://maps.googleapis.com/maps/api/js">
</script>
<script>
function initialize(){
	var mapProp={
	center:new google.maps.LatLng(37.722222,-119.634022),
	zoom: 18,
	mapTypeId: google.maps.MapTypeId.SATELLITE
	};

	var map = new
	google.maps.Map(document.getElementById("googleMap"),mapProp);
	}
google.maps.event.addDomListener(window, 'load',initialize);
</script>
</head>
<body background="pic.jpg">
<font color="white">
<h1><u> Store Locations</u></h1>
<div id="googleMap" style="width:500px;height:380px;"></div>
<h3> We can be found throughout the United States, the locations are as follows:</h3>
<h4><u> Queens</u><br>000 Queens Blvd<br>Long Island, New York 44444</h4><br>
<h4><u>Manhattan</u><br>000 Times Square <br> New York, New York 44444</h4><br>
<h4><u>Brooklyn</u><br> 000 Atlantic Ave <br> Brooklyn, New York 444444</h4><br>

<h3> <a href ="Home.php">Home Page</a></h3>

</body>
</html>
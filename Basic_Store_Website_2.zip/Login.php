<?php
session_start();
include("config.php");
?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/login</title>
<style>
.error{color: #FF0000;}
</style>
</head>
<body background="pic.jpg">
<?php
$Email=$pasword='';
$EmailErr=$PasswordErr='';

if($_SERVER["REQUEST_METHOD"]=="POST"){

if(empty($_POST['email2']) or $_POST['email2']== NULL){
	$EmailErr="Email required!";
}else{
	$Email=Check($_POST['email2']);
	if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
			$EmailErr="invalid Email!";
			}
}
if(empty($_POST['password2']) or $_POST['password2']== NULL){
	$PasswordErr="Enter a Password";
}else{
	
	$password = md5(Check($_POST['password2']));
	
}
$query= "SELECT * from userinfo WHERE Email='$Email'";
$result= mysqli_query($connection, $query);		
$row = mysqli_fetch_array($result);
$db_email=$row['Email'];
$db_password=$row['Password'];	


if($db_email==$Email && $db_password==$password){
	$_SESSION['Name']=$row['First_Name'];
	$_SESSION['isLog']=TRUE;
		
	echo"SUCESSFUL LOGIN! ".$_SESSION['Name'];
	
	redirect_to("Home.php");
	
	}
	else{
	echo "Login failed..";		
	}

}
function Check($data){
	$data= trim($data);
	$data= stripslashes($data);
	$data= htmlspecialchars($data);
	$data= strip_tags($data);
	return $data;
}
function redirect_to($New_Location){
	header("Location: ".$New_Location);
	exit;
}
?>
<font color="white">

<h1>Log in</h1>

<form method="post" action= "<?php echo
htmlspecialchars($_SERVER["PHP_SELF"]);?>">

<fieldset>
E-mail:<br> 
<input type='text' name ='email2' value="<?php echo $Email;?>" />
<span class="error">*<?php echo $EmailErr;?></span>
<br>
Password: <br>
<input type='password' name='password2'/>
<span class="error">*<?php echo $PasswordErr;?></span>
<br>
<br>
<input type ="submit" name="submit" value='Submit'/>

</fieldset>
</form>
</font>

<br>
<h3> <a href ="Home.php">Home Page</a></h3>

</body>
</html>
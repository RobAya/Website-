<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/cart</title>
<style> 
</style>
</head>
<body background="pic.jpg">
<font color="white">
<?php
if($_SESSION['isLog']==TRUE){
	unset ($_SESSION['cart']);
	unset ($_SESSION['qty']);
echo"<h2>Your cart is now empty!</h2><br>";
}
?>
</font>
<h1>
<a href="cart.php">Cart </a>
<br> <br>
<a href="deals2.php">Store </a>
<br>
</h1>
</body>
</html>

<?php
session_start();

include("config.php");
?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/deals</title>
<style> 
</style>
</head>
<body background="pic.jpg">
<font color="white">
<h1> <a href="cart.php" style="float:right">view cart</a> </h1>
<?php
$query="SELECT * FROM stock WHERE type = 'phones'";
$result= mysqli_query($connection,$query);

$printHeader= false;

while($row= mysqli_fetch_row($result)){

echo '<table border="1" cellpadding="0" cellspacing ="30" width="1200">';

if($printHeader == false){
	echo'<th> <h1>Phones</h1> </th>';
	$printHeader = true;
	}

?>

<tbody>
<tr>
	<td align="left" width="200" height="165" bgcolor="#ffffff" valign="top">
<img src="<?php echo $row[2]; ?>"width="180" height="180">
	</td>
	<td align ="right" width="1000" height="165" valign ="top">
	<p align="center"><B> <?php echo $row[1];?></B> <br> 
	
    <?php echo $row[3];?> 	
</p>
	</td>
	<td width="300">
	<h1 align="center"> Buy: <?php echo "$".number_format((float)$row[5], 2, '.', '');?> 
	
<form action="addtocart.php?id=<?php echo $row[0];?> " method="post">	
	<input type="number" name="itemqty" min='1' max='5'/>
	<input type='submit' name='Addcart' value='Add to Cart' /> 
</form>
	</h1>
	</td>
</tr>	
</tbody>
</table>
<?php
}
?>
<?php
$query="SELECT * FROM stock WHERE type = 'computers'";
$result= mysqli_query($connection,$query);
$printHeader = false;
while($row= mysqli_fetch_row($result)){

echo '<table border="1" cellpadding="0" cellspacing ="30" width="1200">';

if($printHeader == false){
	echo'<th> <h1>Computers</h1> </th>';
	$printHeader = true;
}

?>
<tbody>
<tr>
	<td align="left" width="200" height="165" bgcolor="#ffffff" valign="top">
<img src="<?php echo $row[2]; ?>"width="180" height="180">
	</td>
	<td align ="right" width="1000" height="165" valign ="top">
	<p align="center"><B> <?php echo $row[1];?></B> <br> 
	
    <?php echo $row[3];?> 	
</p>
	</td>
	<td width="300">
	<h1 align="center"> Buy: <?php echo "$".number_format((float)$row[5], 2, '.', '');?> 
<form action="addtocart.php?id=<?php echo $row[0];?> " method="post">	
	<input type="number" name="itemqty" min='1' max='5'/>
	<input type='submit' name='Addcart' value='Add to Cart' /> 
</form>
	</h1>
	</td>
</tr>	
</tbody>
</table>
<?php
}
?>

<?php
$query="SELECT * FROM stock WHERE type = 'blenders'";
$result= mysqli_query($connection,$query);
$printHeader = false;
while($row= mysqli_fetch_row($result)){

echo '<table border="1" cellpadding="0" cellspacing ="30" width="1200">';

if($printHeader == false){
	echo'<th> <h1>Blenders</h1> </th>';
	$printHeader = true;
}

?>
<table border="1" cellpadding="0" cellspacing ="30" width="1200">
<tbody>
<tr>
	<td align="left" width="200" height="165" bgcolor="#ffffff" valign="top">
<img src="<?php echo $row[2]; ?>"width="180" height="180">
	</td>
	<td align ="right" width="1000" height="165" valign ="top">
	<p align="center"><B> <?php echo $row[1];?></B> <br> 
	
    <?php echo $row[3];?> 	
</p>
	</td>
	<td width="300">
	<h1 align="center"> Buy: <?php echo "$".number_format((float)$row[5], 2, '.', '');?> 
<form action="addtocart.php?id=<?php echo $row[0];?> " method="post">	
	<input type="number" name="itemqty" min='1' max='5'/>
	<input type='submit' name='Addcart' value='Add to Cart' /> 
</form> 
	</h1>
	</td>
</tr>	
</tbody>
</table>
<?php
}
?>
</font>
<h3> <a href ="Home.php">Home Page</a></h3>

</body>
</html>
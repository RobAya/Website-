-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2016 at 01:55 AM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accountinfo`
--
CREATE DATABASE IF NOT EXISTS `accountinfo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `accountinfo`;

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product` varchar(50) NOT NULL,
  `image` varchar(20) NOT NULL,
  `details` varchar(1000) NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `price` decimal(10,0) UNSIGNED NOT NULL,
  `type` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `product`, `image`, `details`, `quantity`, `price`, `type`) VALUES
(1, 'Nexus 6p', 'ppic.jpg', 'All-metal design Unlocked, LTE smartphone with a powerful 2GHz Snapdragon 810 V2.1 Processor and the newest Android software, Android 6.0 marshmallow.\n    A 5.7-Inch, high-resolution wqhd AMOLED display and front-facing stereo speakers to experience your photos and videos in cinematic Quality.\n    The powerful 12 MP Camera was built to capture your world in true-to-life detail. Larger 1.55 µM pixels absorb more light¹ in even the dimmest conditions to make your photos Brighter.\n    Quicker access and more security with a fingerprint sensor placed on the back to complement the way you naturally hold your Phone.\n    Long lasting 3,450 mAh battery with quick charging USB Type-C plug. its reversible, so theres no more guessing which way is up.', 20, '550', 'phones'),
(2, 'iPhone SE', 'ppic2.jpg', 'Retina display; 4inch (diagonal) LEDbacklit widescreen MultiTouch display\r\n    12megapixel iSight camera with 1.22µ pixels; f/2.2 aperture; Hybrid IR filter; Panorama (up to 63 megapixels)\r\n    4K video recording (3840 by 2160) at 30 fps; Slomo video support for 1080p at 120 fps and 720p at 240 fps; Take 8-megapixel still photos while recording 4K video\r\n    FaceTime HD Camera: 1.2megapixel photos; f/2.4 aperture; Improved local tone mapping; Retina Flash; Talk time: Up to 14 hours on 3G\r\n    Fingerprint sensor built into the Home button; A9 chip with 64bit architecture; Embedded M9 motion coprocessor', 20, '573', 'phones'),
(3, 'iPhone 6s', 'ppic3.jpg', 'Comes with Easy to use iOS 9 with refinements at every level from the apps you see on your Home screen down to the foundation of the system Keep everything you love about iPhone up to date, secure, and accessible from any device with iCloud. With just a single press, 3D Touch lets you do more than ever before. The 12-megapixel iSight camera captures sharp, detailed photos. It takes 4K video, up to four times the resolution of 1080p HD video. iPhone 6s is powered by the custom-designed 64-bit A9 chip.- delivers 70% more CPU performance', 20, '830', 'phones'),
(4, 'Samsing Galaxy S7', 'ppic4.jpg', 'International Version- Product may not have US Warranty Fast battery charging: 60% in 30 min (Quick Charge 2.0); Wireless charging (Qi/PMA) ; Corning Gorilla Glass back panel; Super AMOLED capacitive touchscreen, 16M colors; 5.1 inches (~72.1% screen-to-body ratio) Dual-core 2.15 GHz Kryo & dual-core 1.6 GHz Kryo; Quad-core 2.3 GHz Mongoose + quad-core 1.6 GHz Cortex-A53 Unlocked cell phones are compatible with GSM carriers like AT&T and T-Mobile as well as with GSM SIM cards (e.g. H20, Straight Talk, and select prepaid carriers). Unlocked cell phones will not work with CDMA Carriers like Sprint, Verizon, Boost or Virgin.', 20, '611', 'phones'),
(5, 'BLU Studio Energy', 'ppic5.jpg', '5,000mAh Super Battery: Go Up to 4 Days on Standard Usage with a Single Charge, or 45 days stand-by. 5.0" HD IPS Display (300ppi), 8MP Main Camera + 2MP Front Camera, MediaTek Quad Core 1.3GHz Processor with ARM Mali-400 GPU Unlocked Dual Sim Phone, Android 4.4 Kit Kat upgradeable to Android 5.0 Lollipop, 8GB Internal Storage 1GB RAM with Micro SD Slot up to 64GB GSM Quad Band 4G HSPA+ (850/1700/1900): US Compatibility Nationwide on all GSM Networks including AT&T, T-Mobile, Cricket, MetroPCS, Straight Talk and others ', 20, '134', 'phones'),
(6, 'Sony Xperia Z5', 'ppic6.jpg', '23MP Camera with the worlds fastest Autofocus*, highest low-light sensitivity, and highest dxo Score for video stabilization PS4 Remote Play lets you extend your PlayStation games on your Phone via your local Wi-Fi Hi-Res audio delivers a fully immersive and spectacularly detailed audio experience Water and dust resistant design keeps you going even in a downpour SIM Unlocked means no contracts or commitment to a Specific carrier. A Nano SIM card is required.', 20, '500', 'phones'),
(7, 'Asus Gaming Laptop', 'Lpic.jpg', ' ASUS G751JL 17-Inch Gaming Laptop [2014 model]\r\n	 Intel Core i7-4720HQ 2.6GHz (turbo up to 3.6 GHz). 16 GB RAM.\r\n	1 TB 5400RPM Hard Drive.\r\n	NVIDIA GeForce GTX 965M with 2GB DDR5 VRAM (G-Sync)\r\n	17.3" IPS FHD matte display (1920x1080) with built in G-Sync hardware.\r\n	Gigabit dual-band 802.11AC ultra-fast Wi-Fi. 10/100/10000 Gigabit ethernet\r\n	4x USB 3.0, 1x Thunderbolt 2, 1x HDMI, 1x VGA/Mini D-sub 15-pin, 1x SPDIF, 1x Headphone-out, 1x Mic-in.\r\n	Intelligent Thermal Design, rear venting design directs heat away. Separate thermal modules for the CPU and GPU. Specially-designed Game Keys.', 20, '1100', 'computers'),
(8, 'Apple MacBook Pro', 'Lpic2.jpg', '2.7 GHz Intel Core i5 (Broadwell) 8GB of Onboard 1866 MHz LPDDR3 RAM\r\n	128GB PCIe-Based Flash Storage Integrated Intel Iris Graphics 6100	\r\n	13.3" LED-Backlit IPS Retina Display 2560 x 1600 Native Resolution\r\n	802.11a/b/g/n/ac Wi-Fi, Bluetooth 4.0 Thunderbolt 2, USB 3.0, HDMI\r\n	Force Touch Trackpad Mac OS X 10.10 or 10.11\r\n	Non-Removable Lithium-Polymer Providing up to 10 Hours per Charge', 20, '1149', 'computers'),
(9, 'HP 15t Laptop', 'Lpic3.jpg', '	15.6-inch i7-6500U 8GB 1TB HDD Windows 10 Noble Blue Laptop\r\n	 Processor: Intel Core i7-6500U Dual Core Processor (4MB Cache, 2.5GHz-3.1GHz) 15W\r\n	RAM: 8GB DDR3L 1600MHz | Hard Drive: 1TB 5400rpm Hard Disk Drive	\r\n	Optical Drive: SuperMulti 8X DVD+/-R/RW Dual Layer | Operating System: Windows 10 x64\r\n	Graphics Card: Intel HD 520 Graphics | Display: 15.6-inch HD Display (1366 x 768)\r\n	Color: Noble Blue', 20, '600', 'computers'),
(10, 'Hamilton Beach Hand Blender', 'Bpic.jpg', '59785R 2-Speed \r\n	Convenient storage case\r\n	Blends shakes, drink mixes and more right in your glass\r\n	2 versatile attachments: Blending wand and whisk\r\n	2 speed nonslip control\r\n	200 Watts of power', 20, '20', 'blenders'),
(11, 'Ninja Mega Kitchen Blender', 'Bpic2.jpg', 'Whats inside the box!\r\n	4-blade and 6-blade assemblies, dough blade and single-serve blade\r\n    64-oz. round bowl with lid, pitcher lid\r\n    Ninja Mega Kitchen System 72-Oz. Blender\r\n    Owners manual\r\n    Two 16-oz. single serve cups with to-go lids', 20, '160', 'blenders'),
(12, 'Vitamix', 'Bpic3.jpg', 'The BPA-free Eastman Tritan copolyester pitcher holds up to 64 oz. of ingredients.\r\n	Select from 13 different speeds, so you can achieve precise textures. Also features 3 preprogrammed settings for convenience.\r\n	In addition to blending, you''ll be able to chop, cream, heat, grind, churn, liquefy, mix, purée and crush ice.\r\n	The 2 peak HP motor propels the laser-cut, stainless steel hammermill and cutting blades up to 240 mph.\r\n	A spill-proof vented lid with plug keeps the contents inside the blender.\r\n	Features an ergonomic design, so you can comfortably carry the pitcher.\r\n	Lets you push down ingredients without hitting the blades.\r\n	Just add a drop of dish soap and warm water to the blender and run on high for 30 seconds.\r\n	The included Create cookbook features full-color pages in a 3-ring, hard-bound book with an easel back and is filled with recipes from gourmet chefs.', 20, '530', 'blenders');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE IF NOT EXISTS `userinfo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(20) NOT NULL,
  `Last_Name` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`ID`, `First_Name`, `Last_Name`, `Email`, `Password`) VALUES
(5, 'Robert', 'Nible', 'rraya@gmail.com', 'e99a18c428cb38d5f260853678922e03'),
(6, 'jon', 'ggg', 'jon@gmail.com', 'e99a18c428cb38d5f260853678922e03');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

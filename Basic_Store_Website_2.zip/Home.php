<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title>https://www.Goods4Sale.com</title>
<style> html,h1,h2,h3,h4,h5 {font-family: "Lato", sans-serif} 
ul{
	list-style-type:none;
	margin: 0;
	padding: 0;
	overflow:hidden;
	background-color: #cc0000;
}
li {
	float: left;
}
li a {
	display: block;
	color: white;
	text-align: center;
	padding: 14px 16px;
	text-decoration: none;
		
}
li a:hover{
	background-color:#111;s
}
</style>
</head>

<body background="pic.jpg">

<img style="position:relative;" src ="Logo.jpg" width ="200 px" height ="100 px"/>
<?php
if(isset($_SESSION['isLog'])){
	echo"<font color=\"white\"><h1>Welcome, ".$_SESSION['Name']."</h1></font>";
$log="logout.php";
$log2="Log out";
}else{
echo "<font color=\"white\"><h1> Please log in!</h1></font>";
$log="Login.php";
$log2="Log in";
}

?>

<ul>
    <li> <a href = "Home.php" >Home</a></li>
    <li> <a href = "deals2.php">Deals</a></li>
    <li style="float:right"> <a href = "cart.php">Cart</a></li>
    <li style="float:right"> <a href = "AboutUs.php">About us</a></li>
    <li> <a href = "StoreLocation.php">Store Location</a></li>
	
	<li style="float:right"> <a href="<?=$log ?>"><?php echo $log2; ?> </a></li>	
	
	<li style="float:right"><a href="Register.php">Register</a></li>
</ul>
<br>
<font color="white">
<h3 style="position:absolute;">Welcome to Goods4Sale! </h3>
<br>

<h1 style="text-align:center"><br> We sell all kinds of products from Blenders to Laptops!
<br> We are dedicated into bringing you the best service!<br>
<br>
</font>
<img src="Blender_Photo.jpg" align="center" width="500" height="300">
</body>
</html>

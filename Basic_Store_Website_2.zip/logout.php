<?php
session_start();
session_destroy();
?>

<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/logging_out</title>

<style> 
</style>
</head>
<body>
<meta http-equiv="refresh" content="1;url=Login.php"/>

</body>
</html>
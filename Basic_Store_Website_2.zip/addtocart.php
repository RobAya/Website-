<?php
session_start();
if(!isset($_SESSION['isLog'])){
	header("Location: Login.php");
}
if(empty($_SESSION['cart'])){
	
	$_SESSION['cart']=array();
	$_SESSION['qty']=array();
}

echo"Item has been successfully added to yout cart!<br />";
array_push($_SESSION['cart'],$_GET['id']);
array_push($_SESSION['qty'],$_POST['itemqty']);

?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/cart</title>

      <script type="text/javascript">
         
            function Redirect() {
               window.location="deals2.php";
            }
            
            document.write("You will be redirected to store page.");
            setTimeout('Redirect()', 3000);
         
      </script>
	  
</head>
<body>


</body>
</html>
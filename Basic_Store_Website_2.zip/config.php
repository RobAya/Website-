<?php

$connection=mysqli_connect("localhost","root","abc123","accountinfo");
if(mysqli_connect_errno()){
	die("Connection failed!");
	}

?>
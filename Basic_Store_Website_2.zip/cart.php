<?php
session_start();
include('config.php');
	
if(!isset($_SESSION['isLog'])){
	header("Location: Login.php");
}
$total=0;
$item=0;
$qty=0;


?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4Sale.com/cart</title>
<style> 
</style>
</head>
<body background="pic.jpg">
<font color="white">
<h1> Your shopping cart </h1>
<?php
$con=false;
if(!empty($_SESSION['cart'])){
	$con=true;
	
}else{
	echo"<h1>your cart is perhaps empty</h1><br/>";
}

if($con){


if(empty($itemid)){
$itemid=$_SESSION['cart'][$item];

}

while($item<count($_SESSION['cart'])){
if(!empty($itemid)){
$itemid = $_SESSION['cart'][$item];
 
}

$query="SELECT * FROM stock WHERE id ='$itemid'";
$result= mysqli_query($connection, $query);



while($row=mysqli_fetch_assoc($result)){
	
	
echo '<table border="1" cellpadding="0" cellspacing ="30" width="1200">';
echo '<tbody>';
?>
<tr>
	<td align="left" width="200" height="165" bgcolor="#ffffff" valign="top">
<img src="<?php echo $row['image']; ?>"width="180" height="180">
	</td>
	<td align ="center" width="200" height="165" valign ="top">
	<p align="center" style="font-size:150%;"><?php echo $row['product'];?><br>
	</p>
	</td>
	<td width="200" align="center">
	<p style="font-size:150%;">
	Price:<br> <?php echo "$".$row['price'];?>
	</p>
	</td>
	<td width="200">
	<p align="center" style="font-size:150%;">Quantity:<br> 
	<?php echo $_SESSION['qty'][$item]; ?> </td>
	</p>
	
</tr>


</tbody>
</table>
<?php

$qty=$_SESSION['qty'][$item];
$total=($total+($row['price']*$qty));


}
?>
<?php
$item++;
}


echo "<hr><br>";
echo "<h1 align=\"center\" >\tTotal: $".$total."</h1>";
}
?>

<br><br>

<?php
//else{
//	echo"<h1>your cart is empty</h1><br/>";}


?>
</font>
<h3>
<a href ="empty_cart.php"> Empty Cart </a><br><br>
<a href="deals2.php">Store page</a><br><br>
<a href="Home.php">Home Page</a><br>
</h3>
</body>
</html>
<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head><title>www.Goods4sale.com/Aboutus</title></head>
<body background="pic.jpg">
<h1><font color="white"><u> About Us</u></font></h1>
<img src="work.jpg" width= "300px" height="200px"/>
<font color="white">
<h3> Goods4sale is small home made business with the idea of making people online shopping easier for everyone.<br>
 We work hard to provide a service for people around the United states to enjoy<br>
Also to bring whatever you buy on our website to arrive at your house at a reasonable time frame.</h3>
<h1>Hellos Fellow Browser,</h1> 
<p>If you have any questions please dont hesitate to ask us!</p>
<p> You can contact us with the information below and have a good day!</p>
<br>
<h3><u>Contact information</u></h3>
<h4>Email: Support@good4sale.net <h4>
<h4>Phone: 212-444-4444</h4>
<h4>Hours: Weekdays from 10am to 5pm, Weekends: None</h4>
<br>
<h3> <a href ="Home.php">Home Page</a></h3>
</font>
</body>

</html>